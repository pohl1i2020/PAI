const btns = document.querySelectorAll(".buttons")
const btnWygeneruj = document.querySelector("#wygeneruj");
const buttons = document.querySelector('.buttons');

btnWygeneruj.addEventListener("click", (evt)=>{
    evt.preventDefault();
    const rows = document.querySelector("#row").value;
    const columns = document.querySelector("#column").value;

    if (rows>0 && columns>0) {
        for (let i = 0; i < rows; i++) {
            

            const th_element = document.createElement('th')
            const row = document.createElement('tr')
            
            for (let j = 0; j < columns; j++) {
                const element = document.createElement('td');
                element.innerHTML = `${ i + 1 }  /  ${ j + 1 }` 
                
                element.style.border='1px solid black'
                
                element.style.padding='1rem'
                element.style.margin='1rem'
                element.style.color='black'
                // th_element.style.display='flex'
                // element.style.backgroundColor='orange'
                if (i==0) {
                    
                    row.appendChild(th_element);
                    th_element.innerHTML = `${ i + 1 }  /  ${ j + 1 }` 
                    
                    th_element.style.border='1px solid black'
                    
                    th_element.style.padding='1rem'
                    th_element.style.margin='1rem'
                    th_element.style.color='black'

                    
                }else{

                

                row.appendChild(element);
                element.addEventListener('click', (evt)=>{
                    evt.preventDefault();
                    element.style.backgroundColor='red'
                    // element.style.backgroundColor='white'
                })
            }}
            buttons.appendChild(row);
        }
        
    }


})

